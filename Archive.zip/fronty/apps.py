from django.apps import AppConfig


class FrontyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fronty'
